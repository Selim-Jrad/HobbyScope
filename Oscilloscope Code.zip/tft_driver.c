/*
 * TFT Display Driver (ILI9341/ST7789)
 * Adapt this for your specific TFT controller
 */

#include "stm32g0xx_hal.h"
#include "tft_driver.h"

// Pin definitions - adjust for your hardware
#define TFT_CS_PIN    GPIO_PIN_4
#define TFT_CS_PORT   GPIOA
#define TFT_DC_PIN    GPIO_PIN_3
#define TFT_DC_PORT   GPIOA
#define TFT_RST_PIN   GPIO_PIN_2
#define TFT_RST_PORT  GPIOA

#define TFT_CS_LOW()   HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_RESET)
#define TFT_CS_HIGH()  HAL_GPIO_WritePin(TFT_CS_PORT, TFT_CS_PIN, GPIO_PIN_SET)
#define TFT_DC_LOW()   HAL_GPIO_WritePin(TFT_DC_PORT, TFT_DC_PIN, GPIO_PIN_RESET)
#define TFT_DC_HIGH()  HAL_GPIO_WritePin(TFT_DC_PORT, TFT_DC_PIN, GPIO_PIN_SET)
#define TFT_RST_LOW()  HAL_GPIO_WritePin(TFT_RST_PORT, TFT_RST_PIN, GPIO_PIN_RESET)
#define TFT_RST_HIGH() HAL_GPIO_WritePin(TFT_RST_PORT, TFT_RST_PIN, GPIO_PIN_SET)

extern SPI_HandleTypeDef hspi1;

// Simple 8x8 font
const uint8_t font8x8[96][8] = {
    // Basic ASCII characters 32-127
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // Space
    {0x18, 0x3C, 0x3C, 0x18, 0x18, 0x00, 0x18, 0x00}, // !
    {0x36, 0x36, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // "
    // ... Add full character set as needed
};

/*
 * Low-level SPI write
 */
static void TFT_SPI_Write(uint8_t data)
{
    HAL_SPI_Transmit(&hspi1, &data, 1, HAL_MAX_DELAY);
}

static void TFT_SPI_Write16(uint16_t data)
{
    uint8_t buf[2];
    buf[0] = data >> 8;
    buf[1] = data & 0xFF;
    HAL_SPI_Transmit(&hspi1, buf, 2, HAL_MAX_DELAY);
}

/*
 * Send command to TFT
 */
static void TFT_WriteCommand(uint8_t cmd)
{
    TFT_DC_LOW();
    TFT_CS_LOW();
    TFT_SPI_Write(cmd);
    TFT_CS_HIGH();
}

/*
 * Send data to TFT
 */
static void TFT_WriteData(uint8_t data)
{
    TFT_DC_HIGH();
    TFT_CS_LOW();
    TFT_SPI_Write(data);
    TFT_CS_HIGH();
}

static void TFT_WriteData16(uint16_t data)
{
    TFT_DC_HIGH();
    TFT_CS_LOW();
    TFT_SPI_Write16(data);
    TFT_CS_HIGH();
}

/*
 * Initialize TFT display
 */
void TFT_Init(void)
{
    // Hardware reset
    TFT_RST_HIGH();
    HAL_Delay(5);
    TFT_RST_LOW();
    HAL_Delay(20);
    TFT_RST_HIGH();
    HAL_Delay(150);
    
    // ILI9341 initialization sequence
    TFT_WriteCommand(0x01); // Software reset
    HAL_Delay(150);
    
    TFT_WriteCommand(0x28); // Display OFF
    
    TFT_WriteCommand(0xCF);
    TFT_WriteData(0x00);
    TFT_WriteData(0xC1);
    TFT_WriteData(0x30);
    
    TFT_WriteCommand(0xED);
    TFT_WriteData(0x64);
    TFT_WriteData(0x03);
    TFT_WriteData(0x12);
    TFT_WriteData(0x81);
    
    TFT_WriteCommand(0xE8);
    TFT_WriteData(0x85);
    TFT_WriteData(0x00);
    TFT_WriteData(0x78);
    
    TFT_WriteCommand(0xCB);
    TFT_WriteData(0x39);
    TFT_WriteData(0x2C);
    TFT_WriteData(0x00);
    TFT_WriteData(0x34);
    TFT_WriteData(0x02);
    
    TFT_WriteCommand(0xF7);
    TFT_WriteData(0x20);
    
    TFT_WriteCommand(0xEA);
    TFT_WriteData(0x00);
    TFT_WriteData(0x00);
    
    TFT_WriteCommand(0xC0); // Power control
    TFT_WriteData(0x23);    // VRH[5:0]
    
    TFT_WriteCommand(0xC1); // Power control
    TFT_WriteData(0x10);    // SAP[2:0];BT[3:0]
    
    TFT_WriteCommand(0xC5); // VCM control
    TFT_WriteData(0x3e);
    TFT_WriteData(0x28);
    
    TFT_WriteCommand(0xC7); // VCM control2
    TFT_WriteData(0x86);
    
    TFT_WriteCommand(0x36); // Memory Access Control
    TFT_WriteData(0x48);    // Landscape mode
    
    TFT_WriteCommand(0x3A); // Pixel Format
    TFT_WriteData(0x55);    // 16-bit color
    
    TFT_WriteCommand(0xB1); // Frame Rate Control
    TFT_WriteData(0x00);
    TFT_WriteData(0x18);
    
    TFT_WriteCommand(0xB6); // Display Function Control
    TFT_WriteData(0x08);
    TFT_WriteData(0x82);
    TFT_WriteData(0x27);
    
    TFT_WriteCommand(0xF2); // 3Gamma Function Disable
    TFT_WriteData(0x00);
    
    TFT_WriteCommand(0x26); // Gamma curve selected
    TFT_WriteData(0x01);
    
    TFT_WriteCommand(0xE0); // Set Gamma
    TFT_WriteData(0x0F);
    TFT_WriteData(0x31);
    TFT_WriteData(0x2B);
    TFT_WriteData(0x0C);
    TFT_WriteData(0x0E);
    TFT_WriteData(0x08);
    TFT_WriteData(0x4E);
    TFT_WriteData(0xF1);
    TFT_WriteData(0x37);
    TFT_WriteData(0x07);
    TFT_WriteData(0x10);
    TFT_WriteData(0x03);
    TFT_WriteData(0x0E);
    TFT_WriteData(0x09);
    TFT_WriteData(0x00);
    
    TFT_WriteCommand(0xE1); // Set Gamma
    TFT_WriteData(0x00);
    TFT_WriteData(0x0E);
    TFT_WriteData(0x14);
    TFT_WriteData(0x03);
    TFT_WriteData(0x11);
    TFT_WriteData(0x07);
    TFT_WriteData(0x31);
    TFT_WriteData(0xC1);
    TFT_WriteData(0x48);
    TFT_WriteData(0x08);
    TFT_WriteData(0x0F);
    TFT_WriteData(0x0C);
    TFT_WriteData(0x31);
    TFT_WriteData(0x36);
    TFT_WriteData(0x0F);
    
    TFT_WriteCommand(0x11); // Sleep out
    HAL_Delay(120);
    
    TFT_WriteCommand(0x29); // Display on
    TFT_WriteCommand(0x2C); // Memory write
}

/*
 * Set drawing window
 */
void TFT_SetWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
    TFT_WriteCommand(0x2A); // Column address set
    TFT_WriteData16(x0);
    TFT_WriteData16(x1);
    
    TFT_WriteCommand(0x2B); // Row address set
    TFT_WriteData16(y0);
    TFT_WriteData16(y1);
    
    TFT_WriteCommand(0x2C); // Memory write
}

/*
 * Draw single pixel
 */
void TFT_DrawPixel(uint16_t x, uint16_t y, uint16_t color)
{
    if (x >= 320 || y >= 240) return;
    
    TFT_SetWindow(x, y, x, y);
    TFT_WriteData16(color);
}

/*
 * Fill entire screen
 */
void TFT_Fill(uint16_t color)
{
    TFT_SetWindow(0, 0, 319, 239);
    
    TFT_DC_HIGH();
    TFT_CS_LOW();
    
    for (uint32_t i = 0; i < 76800; i++) {
        TFT_SPI_Write16(color);
    }
    
    TFT_CS_HIGH();
}

/*
 * Draw line (Bresenham's algorithm)
 */
void TFT_DrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color)
{
    int16_t dx = abs(x1 - x0);
    int16_t dy = abs(y1 - y0);
    int16_t sx = x0 < x1 ? 1 : -1;
    int16_t sy = y0 < y1 ? 1 : -1;
    int16_t err = dx - dy;
    
    while (1) {
        TFT_DrawPixel(x0, y0, color);
        
        if (x0 == x1 && y0 == y1) break;
        
        int16_t e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x0 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y0 += sy;
        }
    }
}

/*
 * Draw character
 */
void TFT_DrawChar(uint16_t x, uint16_t y, char c, uint16_t color)
{
    if (c < 32 || c > 127) return;
    
    const uint8_t* glyph = font8x8[c - 32];
    
    for (uint8_t row = 0; row < 8; row++) {
        uint8_t line = glyph[row];
        for (uint8_t col = 0; col < 8; col++) {
            if (line & 0x80) {
                TFT_DrawPixel(x + col, y + row, color);
            }
            line <<= 1;
        }
    }
}

/*
 * Draw string
 */
void TFT_DrawString(uint16_t x, uint16_t y, const char* str, uint16_t color)
{
    while (*str) {
        TFT_DrawChar(x, y, *str++, color);
        x += 8;
        if (x >= 320) {
            x = 0;
            y += 8;
        }
    }
}
