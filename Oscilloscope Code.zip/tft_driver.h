/*
 * TFT Display Driver Header
 */

#ifndef TFT_DRIVER_H
#define TFT_DRIVER_H

#include <stdint.h>

// Function prototypes
void TFT_Init(void);
void TFT_Fill(uint16_t color);
void TFT_DrawPixel(uint16_t x, uint16_t y, uint16_t color);
void TFT_DrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color);
void TFT_DrawChar(uint16_t x, uint16_t y, char c, uint16_t color);
void TFT_DrawString(uint16_t x, uint16_t y, const char* str, uint16_t color);
void TFT_SetWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);

#endif // TFT_DRIVER_H
