/*
 * DIY Oscilloscope for STM32G071CBT
 * Features: Dual ADC input (1x/10x), TFT display, 4 buttons + rotary encoder
 * Trigger modes, waveform capture, and measurements
 */

#include "stm32g0xx_hal.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

// Configuration
#define SAMPLE_BUFFER_SIZE 1024
#define DISPLAY_WIDTH 320
#define DISPLAY_HEIGHT 240
#define WAVEFORM_HEIGHT 180
#define WAVEFORM_Y_OFFSET 30

// ADC Configuration
#define ADC_RESOLUTION 4096  // 12-bit ADC
#define VREF 3.3f

// Button definitions
typedef enum {
    BTN_MENU = 0,
    BTN_UP,
    BTN_DOWN,
    BTN_SELECT
} Button_t;

// Trigger modes
typedef enum {
    TRIG_AUTO = 0,
    TRIG_NORMAL,
    TRIG_SINGLE
} TriggerMode_t;

// Trigger edge
typedef enum {
    TRIG_RISING = 0,
    TRIG_FALLING
} TriggerEdge_t;

// Probe attenuation
typedef enum {
    PROBE_1X = 0,
    PROBE_10X
} ProbeAtten_t;

// Menu states
typedef enum {
    MENU_TIMEBASE = 0,
    MENU_VOLTAGE,
    MENU_TRIGGER_LEVEL,
    MENU_TRIGGER_MODE,
    MENU_PROBE
} MenuState_t;

// Timebase settings (us per division)
const uint16_t timebase_values[] = {1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000};
const char* timebase_labels[] = {"1us", "2us", "5us", "10us", "20us", "50us", "100us", "200us", "500us", "1ms", "2ms", "5ms"};

// Voltage settings (V per division)
const float voltage_values[] = {0.1, 0.2, 0.5, 1.0, 2.0, 5.0};
const char* voltage_labels[] = {"100mV", "200mV", "500mV", "1V", "2V", "5V"};

// Global variables
uint16_t sample_buffer[SAMPLE_BUFFER_SIZE];
uint16_t display_buffer[DISPLAY_WIDTH];
volatile uint16_t sample_index = 0;
volatile uint8_t capture_complete = 0;

// Oscilloscope settings
struct {
    uint8_t timebase_index;
    uint8_t voltage_index;
    uint16_t trigger_level;
    TriggerMode_t trigger_mode;
    TriggerEdge_t trigger_edge;
    ProbeAtten_t probe_atten;
    MenuState_t current_menu;
    uint8_t running;
    uint8_t hold;
} osc_settings = {
    .timebase_index = 5,      // 50us
    .voltage_index = 3,       // 1V
    .trigger_level = 2048,    // Mid-range
    .trigger_mode = TRIG_AUTO,
    .trigger_edge = TRIG_RISING,
    .probe_atten = PROBE_1X,
    .current_menu = MENU_TIMEBASE,
    .running = 1,
    .hold = 0
};

// Measurement results
struct {
    float vpp;      // Peak-to-peak voltage
    float vmax;     // Maximum voltage
    float vmin;     // Minimum voltage
    float vavg;     // Average voltage
    float freq;     // Frequency
    float duty;     // Duty cycle
} measurements;

// External peripheral handles (to be initialized in main)
extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim1;
extern SPI_HandleTypeDef hspi1;  // For TFT

// Function prototypes
void ADC_Start_Continuous(void);
void Process_Samples(void);
void Find_Trigger_Point(uint16_t* trigger_idx);
void Calculate_Measurements(void);
void Draw_Waveform(void);
void Draw_Grid(void);
void Draw_Status(void);
void Handle_Buttons(void);
void Handle_Encoder(int8_t direction);
uint16_t ADC_to_Voltage_Pixels(uint16_t adc_value);
float ADC_to_Voltage(uint16_t adc_value);

// TFT Drawing functions (implement based on your display driver)
void TFT_Fill(uint16_t color);
void TFT_DrawPixel(uint16_t x, uint16_t y, uint16_t color);
void TFT_DrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color);
void TFT_DrawString(uint16_t x, uint16_t y, const char* str, uint16_t color);
void TFT_DrawChar(uint16_t x, uint16_t y, char c, uint16_t color);

// Colors (RGB565)
#define COLOR_BLACK   0x0000
#define COLOR_WHITE   0xFFFF
#define COLOR_GREEN   0x07E0
#define COLOR_YELLOW  0xFFE0
#define COLOR_CYAN    0x07FF
#define COLOR_RED     0xF800
#define COLOR_BLUE    0x001F
#define COLOR_GRAY    0x7BEF

/*
 * Main oscilloscope loop
 */
void Oscilloscope_Run(void)
{
    while(1)
    {
        Handle_Buttons();
        
        if (osc_settings.running && !osc_settings.hold)
        {
            ADC_Start_Continuous();
            
            // Wait for capture complete or timeout
            uint32_t timeout = HAL_GetTick() + 1000;
            while (!capture_complete && HAL_GetTick() < timeout) {
                // Wait
            }
            
            if (capture_complete)
            {
                capture_complete = 0;
                Process_Samples();
                Calculate_Measurements();
                
                TFT_Fill(COLOR_BLACK);
                Draw_Grid();
                Draw_Waveform();
                Draw_Status();
                
                if (osc_settings.trigger_mode == TRIG_SINGLE) {
                    osc_settings.hold = 1;
                }
            }
        }
        
        HAL_Delay(10);
    }
}

/*
 * Start ADC continuous conversion with DMA
 */
void ADC_Start_Continuous(void)
{
    sample_index = 0;
    capture_complete = 0;
    
    // Select appropriate ADC channel based on probe setting
    ADC_ChannelConfTypeDef sConfig = {0};
    if (osc_settings.probe_atten == PROBE_1X) {
        sConfig.Channel = ADC_CHANNEL_0;  // 1x input
    } else {
        sConfig.Channel = ADC_CHANNEL_1;  // 10x input
    }
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
    HAL_ADC_ConfigChannel(&hadc1, &sConfig);
    
    // Start ADC with DMA
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)sample_buffer, SAMPLE_BUFFER_SIZE);
}

/*
 * ADC conversion complete callback
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    if (hadc->Instance == ADC1)
    {
        capture_complete = 1;
        HAL_ADC_Stop_DMA(&hadc1);
    }
}

/*
 * Process captured samples and prepare for display
 */
void Process_Samples(void)
{
    uint16_t trigger_idx = 0;
    
    // Find trigger point
    if (osc_settings.trigger_mode != TRIG_AUTO) {
        Find_Trigger_Point(&trigger_idx);
    }
    
    // Decimate or interpolate samples to fit display width
    uint16_t samples_per_pixel = SAMPLE_BUFFER_SIZE / DISPLAY_WIDTH;
    
    for (uint16_t i = 0; i < DISPLAY_WIDTH; i++)
    {
        uint16_t src_idx = (trigger_idx + i * samples_per_pixel) % SAMPLE_BUFFER_SIZE;
        display_buffer[i] = sample_buffer[src_idx];
    }
}

/*
 * Find trigger point in sample buffer
 */
void Find_Trigger_Point(uint16_t* trigger_idx)
{
    *trigger_idx = 0;
    
    for (uint16_t i = 1; i < SAMPLE_BUFFER_SIZE - 1; i++)
    {
        if (osc_settings.trigger_edge == TRIG_RISING)
        {
            if (sample_buffer[i-1] < osc_settings.trigger_level && 
                sample_buffer[i] >= osc_settings.trigger_level)
            {
                *trigger_idx = i;
                return;
            }
        }
        else  // TRIG_FALLING
        {
            if (sample_buffer[i-1] > osc_settings.trigger_level && 
                sample_buffer[i] <= osc_settings.trigger_level)
            {
                *trigger_idx = i;
                return;
            }
        }
    }
}

/*
 * Calculate measurements from captured waveform
 */
void Calculate_Measurements(void)
{
    uint16_t max_adc = 0;
    uint16_t min_adc = 4095;
    uint32_t sum_adc = 0;
    
    // Find min, max, average
    for (uint16_t i = 0; i < SAMPLE_BUFFER_SIZE; i++)
    {
        if (sample_buffer[i] > max_adc) max_adc = sample_buffer[i];
        if (sample_buffer[i] < min_adc) min_adc = sample_buffer[i];
        sum_adc += sample_buffer[i];
    }
    
    measurements.vmax = ADC_to_Voltage(max_adc);
    measurements.vmin = ADC_to_Voltage(min_adc);
    measurements.vpp = measurements.vmax - measurements.vmin;
    measurements.vavg = ADC_to_Voltage(sum_adc / SAMPLE_BUFFER_SIZE);
    
    // Calculate frequency (zero-crossing method)
    uint16_t mid_level = (max_adc + min_adc) / 2;
    uint16_t crossing_count = 0;
    
    for (uint16_t i = 1; i < SAMPLE_BUFFER_SIZE; i++)
    {
        if ((sample_buffer[i-1] < mid_level && sample_buffer[i] >= mid_level) ||
            (sample_buffer[i-1] > mid_level && sample_buffer[i] <= mid_level))
        {
            crossing_count++;
        }
    }
    
    if (crossing_count > 2)
    {
        float time_per_sample = timebase_values[osc_settings.timebase_index] / 1000000.0f;
        float total_time = SAMPLE_BUFFER_SIZE * time_per_sample;
        measurements.freq = (crossing_count / 2.0f) / total_time;
    }
    else
    {
        measurements.freq = 0;
    }
}

/*
 * Convert ADC value to voltage
 */
float ADC_to_Voltage(uint16_t adc_value)
{
    float voltage = (adc_value / (float)ADC_RESOLUTION) * VREF;
    
    if (osc_settings.probe_atten == PROBE_10X) {
        voltage *= 10.0f;
    }
    
    return voltage;
}

/*
 * Convert ADC value to Y pixel position
 */
uint16_t ADC_to_Voltage_Pixels(uint16_t adc_value)
{
    float voltage = ADC_to_Voltage(adc_value);
    float volts_per_div = voltage_values[osc_settings.voltage_index];
    
    // Map to display coordinates (inverted Y axis)
    int16_t pixel_y = WAVEFORM_Y_OFFSET + WAVEFORM_HEIGHT/2;
    pixel_y -= (int16_t)((voltage / volts_per_div) * (WAVEFORM_HEIGHT / 8.0f));
    
    // Clamp to display bounds
    if (pixel_y < WAVEFORM_Y_OFFSET) pixel_y = WAVEFORM_Y_OFFSET;
    if (pixel_y > WAVEFORM_Y_OFFSET + WAVEFORM_HEIGHT) pixel_y = WAVEFORM_Y_OFFSET + WAVEFORM_HEIGHT;
    
    return pixel_y;
}

/*
 * Draw grid on display
 */
void Draw_Grid(void)
{
    // Draw vertical grid lines
    for (uint16_t x = 0; x < DISPLAY_WIDTH; x += (DISPLAY_WIDTH / 10))
    {
        for (uint16_t y = WAVEFORM_Y_OFFSET; y < WAVEFORM_Y_OFFSET + WAVEFORM_HEIGHT; y += 4)
        {
            TFT_DrawPixel(x, y, COLOR_GRAY);
        }
    }
    
    // Draw horizontal grid lines
    for (uint16_t y = WAVEFORM_Y_OFFSET; y < WAVEFORM_Y_OFFSET + WAVEFORM_HEIGHT; y += (WAVEFORM_HEIGHT / 8))
    {
        for (uint16_t x = 0; x < DISPLAY_WIDTH; x += 4)
        {
            TFT_DrawPixel(x, y, COLOR_GRAY);
        }
    }
    
    // Draw center lines (brighter)
    uint16_t center_y = WAVEFORM_Y_OFFSET + WAVEFORM_HEIGHT / 2;
    TFT_DrawLine(0, center_y, DISPLAY_WIDTH, center_y, COLOR_GREEN);
}

/*
 * Draw waveform on display
 */
void Draw_Waveform(void)
{
    for (uint16_t x = 1; x < DISPLAY_WIDTH; x++)
    {
        uint16_t y1 = ADC_to_Voltage_Pixels(display_buffer[x-1]);
        uint16_t y2 = ADC_to_Voltage_Pixels(display_buffer[x]);
        
        TFT_DrawLine(x-1, y1, x, y2, COLOR_YELLOW);
    }
}

/*
 * Draw status information and measurements
 */
void Draw_Status(void)
{
    char buf[32];
    
    // Timebase
    sprintf(buf, "TB:%s", timebase_labels[osc_settings.timebase_index]);
    TFT_DrawString(5, 5, buf, osc_settings.current_menu == MENU_TIMEBASE ? COLOR_CYAN : COLOR_WHITE);
    
    // Voltage scale
    sprintf(buf, "V:%s", voltage_labels[osc_settings.voltage_index]);
    TFT_DrawString(80, 5, buf, osc_settings.current_menu == MENU_VOLTAGE ? COLOR_CYAN : COLOR_WHITE);
    
    // Trigger mode
    const char* trig_mode_str[] = {"AUTO", "NORM", "SING"};
    sprintf(buf, "TR:%s", trig_mode_str[osc_settings.trigger_mode]);
    TFT_DrawString(150, 5, buf, osc_settings.current_menu == MENU_TRIGGER_MODE ? COLOR_CYAN : COLOR_WHITE);
    
    // Probe setting
    sprintf(buf, "%s", osc_settings.probe_atten == PROBE_1X ? "1X" : "10X");
    TFT_DrawString(220, 5, buf, osc_settings.current_menu == MENU_PROBE ? COLOR_CYAN : COLOR_WHITE);
    
    // Measurements
    uint16_t meas_y = WAVEFORM_Y_OFFSET + WAVEFORM_HEIGHT + 5;
    
    sprintf(buf, "Vpp:%.2fV", measurements.vpp);
    TFT_DrawString(5, meas_y, buf, COLOR_WHITE);
    
    sprintf(buf, "Vmax:%.2fV", measurements.vmax);
    TFT_DrawString(5, meas_y + 15, buf, COLOR_WHITE);
    
    sprintf(buf, "Freq:%.1fHz", measurements.freq);
    TFT_DrawString(160, meas_y, buf, COLOR_WHITE);
    
    if (osc_settings.hold) {
        TFT_DrawString(260, meas_y + 15, "HOLD", COLOR_RED);
    }
}

/*
 * Handle button presses
 */
void Handle_Buttons(void)
{
    static uint32_t last_press = 0;
    uint32_t now = HAL_GetTick();
    
    if (now - last_press < 200) return;  // Debounce
    
    // Read button states (implement GPIO reading for your pins)
    // This is a placeholder - adjust for your actual GPIO configuration
    
    // BTN_MENU - cycle through menus
    // BTN_UP - increment current setting
    // BTN_DOWN - decrement current setting
    // BTN_SELECT - toggle run/hold or apply setting
}

/*
 * Handle rotary encoder rotation
 */
void Handle_Encoder(int8_t direction)
{
    switch (osc_settings.current_menu)
    {
        case MENU_TIMEBASE:
            if (direction > 0 && osc_settings.timebase_index < 11) {
                osc_settings.timebase_index++;
            } else if (direction < 0 && osc_settings.timebase_index > 0) {
                osc_settings.timebase_index--;
            }
            break;
            
        case MENU_VOLTAGE:
            if (direction > 0 && osc_settings.voltage_index < 5) {
                osc_settings.voltage_index++;
            } else if (direction < 0 && osc_settings.voltage_index > 0) {
                osc_settings.voltage_index--;
            }
            break;
            
        case MENU_TRIGGER_LEVEL:
            osc_settings.trigger_level += direction * 100;
            if (osc_settings.trigger_level > 4095) osc_settings.trigger_level = 4095;
            if (osc_settings.trigger_level < 0) osc_settings.trigger_level = 0;
            break;
            
        case MENU_TRIGGER_MODE:
            if (direction > 0) {
                osc_settings.trigger_mode = (osc_settings.trigger_mode + 1) % 3;
            }
            break;
            
        case MENU_PROBE:
            osc_settings.probe_atten = (osc_settings.probe_atten == PROBE_1X) ? PROBE_10X : PROBE_1X;
            break;
    }
}
